
//simpleajax script
//Provides basic functionality to use Ajax to send a request to a php script

//create an instance of the XHR object


let getDataAjax = () => {
url = "getDataAjax.php";
ajaxRequest(url,"GET","",displayData);
// request.onload = displayData;
// request.onerror = displayError;
// request.open("GET", url);
// request.send("");

}

//set the url to the server-side script url = "getDataAjax.php";
//initialise the XHR object request.onload = displayData; request.onerror= displayError; request.open("GET", url); request.send("");
let getCustomer = () => {

    var id = document.getElementById("idnum").value; 
    let customer = id;
    var url = "getCustomer.php";
    var data = "id=" + id;

    ajaxRequest(url,"POST",data,displayCustomerData);
    // //initialise the XHR object
    // request.onload = displayCustomerData;
    // request.onerror = displayError;
    // request.open("POST", url);
    // request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    // request.send(data);
}


let getDebtors = () => {

    //set the url to the server-side script
    url = "getDebtors.php";
    ajaxRequest(url,"GET","",displayDebtors);
    // //initialise the XHR object
    // request.onload = displayDebtors;
    // request.onerror = displayError;
    // request.open("GET", url);
    // request.send("");

}


//call back function which will display the returned data
let displayData = (response) => {


    //var response = request.responseText;
    //put the returned data into the <div> element 
    theDivElement = document.getElementById("data");
    theDivElement.innerHTML = response;

}

let displayCustomerData = (response) => {


    //var response = request.responseText;
    //put the returned data into the <div> element 
    theDivElement = document.getElementById("personInfo");
    theDivElement.innerHTML = response;

}

let displayDebtors = (response) => {
    //var response = request.responseText;
    //put the returned data into the <div> element 
    theDivElement = document.getElementById("debtors");
    theDivElement.innerHTML = response;

}

let displayError = () => {
    console.error("An error occured when fetching the data");

}

let ajaxRequest = (url,method,data,callback) => {

    request = new XMLHttpRequest();
    request.onload = function(){
        response = request.responseText;
        callback(response);
    }
    request.onerror = displayError;
    request.open(method, url);
    if(method == "POST"){
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    }
    request.send(data);

}



