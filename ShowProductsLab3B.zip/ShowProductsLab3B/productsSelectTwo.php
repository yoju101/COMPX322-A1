<?php

  $matchtype = $_POST['match'];
  $usertext = $_POST['text'];
  
  require_once('../../dbconnect.php');
    
    if ($matchtype == "in"){
        $query = "Select * from office_products where name like '%".$usertext."%' and stock > 0";
    }else{
       $query = "Select * from office_products where name like '%".$usertext."%'" ; 
    }
  $result = $con->query($query);


	echo "<table>";
	echo "<tr><th>Products</th></tr>"; 

	while($row = $result->fetch()) {
	 	$txt = $row['name'];
     	echo "<td>".$row['name']."</td><td></td>";
     	echo "</tr>";
  	}
  
  	echo "</table>";


