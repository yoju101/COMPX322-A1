-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 06, 2023 at 08:40 PM
-- Server version: 5.7.30
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `322`
--

-- --------------------------------------------------------

--
-- Table structure for table `office_products`
--

CREATE TABLE `office_products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `office_products`
--

INSERT INTO `office_products` (`id`, `name`, `category`, `price`, `description`, `stock`) VALUES
(1, 'Ballpoint Pens', 'Writing Supplies', '9.99', 'Pack of 10 black pens with medium point', 20),
(2, 'Stapler', 'Desk Supplies', '12.99', 'Full-strip stapler with 20-sheet capacity', 0),
(3, 'Letter Trays', 'Desk Accessories', '19.99', 'Set of 3 stacking trays for organizing papers and documents', 5),
(4, 'Graphite Pencil', 'Writing Supplies', '5.99', 'Pack of 10 HB Pencils', 3),
(5, 'Coloured Pencil', 'Writing Supplies', '11.99', 'Pack of 10 Coloured Pencils', 0),
(6, 'Hole Punch', 'Desk Supplies', '10.99', 'A4 Capacity Hole Punch', 7),
(7, 'Concertina File', 'Desk Accessories', '8.99', 'A-Z Concertina Folder with 500 page capacity', 10),
(8, 'A4 Window Envelopes', 'Writing Supplies', '4.99', 'Pack of 40 A4 window envelopes', 5),
(9, 'A4 Plain Envelopes', 'Writing Supplies', '3.99', 'Pack of 40 A4 plain envelopes', 0),
(10, 'Ruled writing pad', 'Writing Supplies', '10.99', 'Pack of 6 A4 ruled writing pads', 6),
(11, 'Highlighter Pens', 'Writing Supplies', '14.99', 'Pack of 6 multi-coloured highlighter pens', 8),
(12, 'Pen holder', 'Desk Supplies', '4.99', 'Clear plastic pen holder', 0),
(13, 'Ruler', 'Desk Supplies', '4.99', '30cm clear plastic ruler', 9),
(17, 'Ring binders', 'Filing', '14.99', 'A4 Ring binders 10-pack', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `office_products`
--
ALTER TABLE `office_products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `office_products`
--
ALTER TABLE `office_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
