let ajaxRequest = (method, url,data, callback) => {
	let request = new XMLHttpRequest();
	request.open(method,url);
	
	if(method == "POST"){
		request.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	}

	request.onload = function(){
        let response = request.responseText;
        callback(response);
	}
	
	request.send(data);
}

let suggestItems = () => {
    //check if user wants to just see items in stock or all items
	let radios = document.getElementsByName("matchgroup");
	let i;
	for (i = 0; i < radios.length; i++) {
		if (radios[i].checked) break;
	}
	let match = radios[i].value;
    
	let usertext = document.getElementById("usertext").value;
	if (usertext != "") {
		let url = "productsSelectTwo.php";
        let text = "text=" + usertext +"&match="+match;
		ajaxRequest("POST", url, text, processResult);
	} 
}
let processResult = (response) => {

	let suggestions = document.getElementById("suggestions");
	suggestions.innerHTML = response;
        
}

