<!-- this php is to update the sql file with the selected radio button value  -->

<?php
   //echo("The addsTopics php is called");
	//first connect to the database 
    require_once('connection.php'); 
    //get the value  of the radio buttons from ajax
    $topic = $_POST['topic'];

    //echo "Value received from JavaScript: " . $topic;

   // $sql = "UPDATE newtopics set '%".$topic."%' WHERE '%".$checked."'%";
    $sql = "UPDATE newtopics SET active = 1 WHERE topic = '$topic'";
    $result = $con->query($sql);

   


    
