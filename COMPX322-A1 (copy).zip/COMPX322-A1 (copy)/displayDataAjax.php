<?php
//first connect to the database   
//require_once('C:\xampp\htdocs\322\As1\connection.php');
require_once('connection.php'); 

 // Fetch topics from the database by creating the sql query and send it
 $query = "select * from `newtopics` WHERE `active` = 1";
 $result = $con->query($query);

$topicsArray = array();
  //if we get data back display it using a table
  if($result != FALSE) 
  {
      while($row = $result->fetch()) 
      {
          //gets the data from topic and itterates through the loop
         echo $row['topic'] . " " ;
         echo "<br>";
$topicsArray[] = $row['topic'];
      }
   }
   // Encode the array as JSON
$topicsJson = json_encode($topicsArray);
//echo $topicsJson; testing


    // Assign PHP variable to JavaScript variable


    // Now you can use topicsArray in your external JavaScript file
    echo "<form action='ajax.js'>";
    //echo "var topicsArray = $topicsJson ;";
    //echo "passArray($topicsJson);";
    echo "</form>";



