<?php
try{
$con = new PDO('mysql:host=learn-mysql.cms.waikato.ac.nz;dbname=yv4','yv4','my217158sql');
} catch (PDOException $e) {
echo "Database connection error ". $e->getMessage();
}
