//simpleajax script
//Provides basic functionality to use Ajax to send a request to a php script

//create an instance of the XHR object
let displayTopics = () => {
    url = "displayDataAjax.php";
    ajaxRequest(url,"GET","",displayData);
    }
    //call back function which will display the returned data
    let displayData = (response) => {
        theDivElement = document.getElementById("data");
        theDivElement.innerHTML = response;
        // var ar = JSON.parse(response);
        // alert(ar);
    }
    
    //getActiveStatus with class container id value passed 
    //through the dom and using a post request to get the value
    let getInactiveTopics = () => {
        url = "getInactiveTopics.php";
        ajaxRequest(url,"GET","",displayActiveData);
    
    }
    let getActiveTopics =  () =>{
        url = "getActiveTopics.php";
        ajaxRequest(url,"GET","",displayActiveData);
    }
//this function adds the item to the list
    let radioSelectedValue = () =>{
        // alert("button clicked");
        topic = document.querySelector('input[name="topic"]:checked').value;
        let  topicChosen = topic;  
        url = "addsTopics.php";
        var data ="topic=" + topic;
        ajaxRequest(url,"POST",data,displayActiveData);
        // alert("You selected: "+ topic );
        //getWeatherList(topic); // pass the value of topic to getWeatherList
        //useApi(topicChosen);
       displayTopics();
    }
    //this function removes the item from the list
    let radioSelectedActiveValue = ()=>{
         //alert("button remove clicked");
        topic = document.querySelector('input[name="topic"]:checked').value;
        let  topicChosen = topic;  
        url = "removeTopics.php";
        var data ="topic=" + topic;
        ajaxRequest(url,"POST",data,displayInactiveData);
        //alert("You selected: "+ topic );
        //getWeatherList(topic); // pass the value of topic to getWeatherList
        displayTopics();
        
    }
        //console.log(topicChosen);
    let displayActiveData = (response) => {
    
        theDivElement = document.getElementById("containerAdd");
        theDivElement.innerHTML = response;
        
    }
    let displayInactiveData = (response) => {
    
        theDivElement = document.getElementById("containerRemove");
        theDivElement.innerHTML = response;

    }
    
    
    let displayError = () => {
        console.error("An error occured when fetching the data");
    
    }
    
    
    let ajaxRequest = (url,method,data,callback) => {
    
        request = new XMLHttpRequest();
        request.onload = function(){
            response = request.responseText;
            callback(response);
        }
        request.onerror = displayError;
        request.open(method, url);
        if(method == "POST"){
            request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        }
        request.send(data);
    
    }
    
/////////////////////////////////////////////////////////////////////////////////////

// document.addEventListener("DOMContentLoaded", function() {
//     // Add event listener to the country select dropdown
//     document.getElementById('countrySelect').addEventListener('change', function() {
//       // Call getWeatherList function when the selection changes
//       getWeatherList();
//     });
//     // Call getWeatherList function initially to load news for the default location
//     getWeatherList();
//   });

// //the fetch request that is triggered when the Show news articals buttons is clicked 
// //the getWeatherList () takes in the catagory of the current active topic that is chosen in the radioselect button above
// function getWeatherList(category) {
//     // Get the selected country code
//     const selectedLoc = document.getElementById('countrySelect').value;

//     fetch(" https://api.thenewsapi.com/v1/news/top?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&locale=" + selectedLoc + "&limit=3")
//       .then(response => response.json())
//       //.then(addtoList)
//      // .then(data => console.log(data))
//       .then(data => {
//         const newsArray = data.data;
  
//         // Clear previous news articles
//         document.getElementById('news').innerHTML = '';

//         // If no news headlines are returned 
//       if (newsArray.length === 0) {
//         const newsDiv = document.getElementById('news');
//         const noNewsMessage = document.createElement('p');
//         noNewsMessage.textContent = "No news headlines found.";
//         newsDiv.appendChild(noNewsMessage);
//         return; // Exit the function
//       }
  
//         // Iterate over each news item
//         newsArray.forEach(newsItem => {
//           // Extract title and URL
//           const title = newsItem.title;
//           const url = newsItem.url;
//           const location = newsItem.locale;
//           console.log('this is the loc ' + location);
//           const categorie = newsItem.categories;
//           categorie == category;
//           console.log('this is the topic ' + category);
  
//           // Create HTML elements
         
//           const newsTitle = document.createElement('ul');
//           newsTitle.textContent = title;
//           const newsLink = document.createElement('a');
//           newsLink.href = newsLink.textContent = url;
          
  
//           // Append elements to the news div
//           const newsDiv = document.getElementById('news');
//           newsDiv.appendChild(newsTitle);
//           newsDiv.appendChild(newsLink);
//           newsDiv.appendChild(document.createElement('hr')); // Add a horizontal line between articles
//         });
//       })
//       .catch(error => console.error('Error:', error));

//   }


// /////////////////////////////////////////////////////////////////////////////////

document.addEventListener("DOMContentLoaded", function() {
    // Add event listener to the country select dropdown
    document.getElementById('countrySelect').addEventListener('change', function() {
      // Call getWeatherList function when the selection changes
      getWeatherList();
    });
    // Call getWeatherList function initially to load news for the default location
    getWeatherList();
  });

//let getWeatherList = () =>{

    function getWeatherList(elements){
        var topic = elements.getAttribute('dataTopic');
        //var topic = document.getElementById('data').value;
        // Now you can use 'topic' variable to make your API request
        console.log("Clicked topic: " + topic);    

//code from the weather api website not my own.
    var requestOptions = {
        method: 'GET'
    };
    //const currentTopic = document.querySelector('input[name="topic"]:checked').value;
    const selectedLoc = document.getElementById('countrySelect').value;
    // console.log("selected topic " + topic);
    
    var params = {
        api_token: 'yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos',
        categories: topic, 
        limit: '3',
        locale: selectedLoc,
    };
    
    var esc = encodeURIComponent;
    var query = Object.keys(params)
        .map(function(k) {return esc(k) + '=' + esc(params[k]);})
        .join('&');
        //https://api.thenewsapi.com/v1/news/top?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&locale=" + selectedLoc + "&limit=3
    fetch("https://api.thenewsapi.com/v1/news/top?" + query, requestOptions)
    .then(response => response.json())
      .then(data => {
        const newsArray = data.data;
    
        // Clear previous news articles
        document.getElementById('news').innerHTML = '';
    
        // If no news headlines are returned 
      if (newsArray.length === 0) {
        const newsDiv = document.getElementById('news');
        const noNewsMessage = document.createElement('p');
        noNewsMessage.textContent = "No news headlines found.";
        newsDiv.appendChild(noNewsMessage);
        return; // Exit the function
      }
    
        // Iterate over each news item
        newsArray.forEach(newsItem => {
          // Extract title and URL
          const title = newsItem.title;
          const url = newsItem.url;
          const location = newsItem.locale;
          console.log('this is the loc ' + location);

          // Create HTML elements
          const newsTitle = document.createElement('ul');
          newsTitle.textContent = title;
          const newsLink = document.createElement('a');
          newsLink.href = newsLink.textContent = url;
          
    
              // Append elements to the news div
              const newsDiv = document.getElementById('news');
              newsDiv.appendChild(newsTitle);
              newsDiv.appendChild(newsLink);
              newsDiv.appendChild(document.createElement('hr')); // Add a horizontal line between articles
            });
          })
          .catch(error => console.error('Error:', error));
    
    }


    