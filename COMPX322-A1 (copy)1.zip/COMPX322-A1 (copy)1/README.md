/////////////////////////////////////////////////////////////////

    //makes a request to the api for the weather
    // getWeatherList = () =>{
    fetch("https://api.thenewsapi.com/v1/news/all?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&search=usd")
          .then(response => response.json())
          .then(data => console.log(data))
          .catch(error => console.error('Error:', error));
    // }
    
    
    //**
    // code from the api website not my own
    //  *
    // var requestOptions = {
    //     method: 'GET'
    // };
    
    // var params = {
    //     api_token: 'yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos',
    //     categories: document.getElementById("data"),
    //     local: document.getElementById("location"),
    //     //title: //get this from the api samehow
    //     //url: //get this from the api somehow
    //     limit: '3'
    // };
    
    // var esc = encodeURIComponent;
    // var query = Object.keys(params)
    //     .map(function(k) {return esc(k) + '=' + esc(params[k]);})
    //     .join('&');
    
    //     fetch("GET https://api.thenewsapi.com/v1/news/top?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&locale=" + local +"&limit=" + limit)
    //   .then(response => response.text())
    //   .then(result => console.log(result))
    //   .catch(error => console.log('error', error));
    
    //populates the dropdown select item with the list of locations

    addtoList = (response) =>{
        //get the list of property names from the json object
        let locationList = Object.keys(response.message);
        
        //create a select option for each item in the array
        const select = document.getElementById("loaction");
        locationList.forEach(b =>{
            const optionElem = document.createElement("option");
            optionElem.value = b;
            optionElem.text = b;
            select.appendChild(optionElem);
        });
    }
    
    //event handler for the dropdown list which triggers request to api for selected location
    handleChange = (e) =>{
        let loc = e.target.value;
    
     let url = "https://api.thenewsapi.com/v1/news/top?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&locale=" + loc +"&limit=" + 3;
        fetch(url)
        .then(response=> response.json());
    
    }
    // Make an HTTP GET request to the API endpoint
// fetch('https://api.thenewsapi.com/v1/news/top?api_token=yJvISyDAXuLVmccVJhTV8FXBB5Ed7eQL3mgoPnos&locale=us&limit=3')
// .then(response => response.json()) // Parse the JSON data
// .then(data => {
//     // Check if data is an array
   
//         // Loop through each item in the array
//         data.forEach(item => {
//             // Extract individual values
//             const title = item.title;
//             const description = item.description;
            
//             // Create HTML elements to display the values
//             const container = document.createElement('div');
//             const titleElement = document.createElement('h3');
//             const descriptionElement = document.createElement('p');
            
//             // Set the content of the HTML elements
//             titleElement.textContent = title;
//             descriptionElement.textContent = description;
            
//             // Append the HTML elements to the container
//             container.appendChild(titleElement);
//             container.appendChild(descriptionElement);
            
//             // Append the container to the document body
//             document.body.appendChild(container);
//         });
     
// })
// .catch(error => {
//     console.error('Error fetching data:', error);
// });
# COMPX322-A1