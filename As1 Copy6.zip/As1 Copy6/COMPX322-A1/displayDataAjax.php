<?php
//first connect to the database   
//require_once('C:\xampp\htdocs\322\As1\connection.php');
require_once('connection.php'); 

 // Fetch topics from the database by creating the sql query and send it
 $query = "select * from `newtopics` WHERE `active` = 1";
 $result = $con->query($query);

$topicsArray = array();
  //if we get data back display it using a table
  if($result != FALSE) 
  {
      while($row = $result->fetch()) 
      {
          //gets the data from topic and itterates through the loop
         echo $row['topic'] . " " ;
         echo "<br>";
$topicsArray[] = $row['topic'];
      }
   }
   // Encode the array as JSON
$topicsJson = json_encode($topicsArray);

?>

   <script>
// Define a JavaScript variable and assign the JSON data
var topicsJson = <?php echo $topicsJson; ?>;
</script>




